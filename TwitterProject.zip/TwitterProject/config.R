#Twitter
appname = ""
consumer_key = ""
consumer_secret = ""
access_token = ""
access_secret = ""
googleAPIkey = ""

#Database
host = "batestocks.cgrwtpcjkd6h.us-west-2.rds.amazonaws.com"
dbname = "TwitterFeed"
user = "school"
password = "password123"