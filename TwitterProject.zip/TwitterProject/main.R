source("forest.R")
source("wordclouds.R")

#You run the program from here.
#This predicts who will win the election.
winnerForest = Random_Forest()

#This generates all of our graphs and workclouds.
#Takes a loooooong time to run. Be prepared.
generateWorldCloud()

print(paste0('The winner is: ', winnerForest))
