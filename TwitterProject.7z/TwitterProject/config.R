#Twitter
appname = "tester7999"
consumer_key = "6iw0FsjOQHFRtBr7mxvcMPB6p"
consumer_secret = "ZGPvoqOrAPWjTVjohjQApihK8sTtu7C7cEcyG5Cjd6TIn8pkp7"
access_token = "1226238287787905024-3vetstvAsdvOeZ6Z32wzdbyR5TBoCV"
access_secret = "AGbRmDELBGqQu3faNuRa8FRIDUfeBQ62yTSV9HO7wfHR8"
googleAPIkey = "AIzaSyBS1m6eT3g45CJKnDL7lt7_SH79mJZN5Sw"

#Database
host = "batestocks.cgrwtpcjkd6h.us-west-2.rds.amazonaws.com"
dbname = "TwitterFeed"
user = "school"
password = "password123"